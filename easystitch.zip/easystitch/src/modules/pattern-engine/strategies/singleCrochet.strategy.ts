/**
 * strategies/singleCrochet.strategy.ts
 *
 * Placeholder for Single Crochet (SC) graphghan strategy.
 *
 * ── What SC graphghan is ──────────────────────────────────────────────────────
 * Visually identical to a standard graphghan — each cell = one stitch.
 * The difference is technical: SC produces a denser, squarer fabric than
 * double crochet graphghan. This affects:
 *   - Recommended grid proportions (SC fabric is ~1:1 stitch-to-row ratio;
 *     DC fabric is ~1:1.3 — grids may need non-square aspect ratios)
 *   - Stitch count metadata in the PDF (SC count ≠ DC count for same size)
 *   - Yarn consumption estimates
 *
 * ── How this strategy will differ from graphghan ──────────────────────────────
 *
 * 1. Grid assembly — SAME as graphghan. No traversal or constraint differences.
 *
 * 2. Aspect ratio correction — SC grids should warn users if width ≠ height,
 *    since SC produces a square stitch. A 40×40 SC pattern makes a square.
 *    A 40×30 SC pattern makes a wider rectangle than the same DC pattern would.
 *
 * 3. Metadata differences:
 *    - stitchStyle: 'singleCrochet'
 *    - PDF instructions reference SC technique instead of DC
 *    - Yarn weight recommendation may differ
 *
 * ── Implementation steps when ready ──────────────────────────────────────────
 * 1. Uncomment and complete execute() — it will be nearly identical to graphghan
 * 2. Add aspect ratio hint to PatternMeta
 * 3. Update PDF template to reference SC terminology
 */

import { PatternData } from '@/types/pattern'
import { StitchStrategy, StrategyInput } from './types'

class SingleCrochetStrategy implements StitchStrategy {
  readonly id             = 'singleCrochet' as const
  readonly displayName    = 'Single Crochet'
  readonly description    = 'Dense, square stitches — tight and detailed'
  readonly traversalOrder = 'rowByRow' as const

  execute(_input: StrategyInput): PatternData {
    // TODO: Implement single crochet strategy
    // Steps:
    // 1. Build grid identically to graphghan
    // 2. Override meta.stitchStyle = 'singleCrochet'
    // 3. Add aspect ratio hint for PDF (SC is 1:1, DC is ~1:1.3)
    throw new Error(
      'Single Crochet strategy is not yet implemented. Use graphghan in the meantime.'
    )
  }
}

export const singleCrochetStrategy = new SingleCrochetStrategy()
