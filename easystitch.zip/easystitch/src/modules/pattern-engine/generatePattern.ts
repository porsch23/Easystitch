/**
 * pattern-engine/generatePattern.ts
 *
 * The single public entry point for the pattern engine.
 * All UI code calls this function — nothing else in this module is imported
 * directly by UI components.
 *
 * Responsibilities:
 *   1. Resize the image to grid dimensions  (image-processing)
 *   2. Reduce colours                       (palette-reduction)
 *   3. Resolve the correct stitch strategy  (strategies/registry)
 *   4. Delegate grid assembly to that strategy
 *   5. Return PatternData
 *
 * This function intentionally contains no grid logic. Adding or changing a
 * stitch style never requires touching this file.
 *
 * Must be called in a browser context (uses canvas API via resizeToGrid).
 */

import { PatternData, PatternSettings } from '@/types/pattern'
import { resizeToGrid }    from '../image-processing/resize'
import { quantizeImage }   from '../palette-reduction/quantize'
import { getStrategy }     from './strategies/registry'

export async function generatePattern(
  imageDataUrl: string,
  settings:     PatternSettings
): Promise<PatternData> {
  const { gridSize, maxColors, stitchStyle } = settings

  // ── Stage 1: Resize image to grid dimensions ───────────────────────────────
  const pixelGrid = await resizeToGrid(imageDataUrl, {
    targetWidth:  gridSize.width,
    targetHeight: gridSize.height,
  })

  // ── Stage 2: Reduce to N colours ───────────────────────────────────────────
  const { palette, colorMap } = quantizeImage(pixelGrid, maxColors)

  // ── Stage 3: Resolve strategy ──────────────────────────────────────────────
  // getStrategy() falls back to graphghan if the style isn't implemented yet,
  // so placeholder strategies never crash the pipeline in production.
  const strategy = getStrategy(stitchStyle)

  // ── Stage 4: Assemble PatternData via strategy ─────────────────────────────
  const patternData: PatternData = strategy.execute({
    pixelGrid,
    palette,
    colorMap,
    settings,
  })

  return patternData
}
