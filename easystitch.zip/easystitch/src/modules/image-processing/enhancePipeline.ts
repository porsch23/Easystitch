/**
 * image-processing/enhancePipeline.ts
 *
 * Orchestrates the preprocessing pipeline and exposes a single async function
 * that the UI calls. This is the only file that needs changing when a future
 * AI service is integrated — all operations stay in enhance.ts.
 *
 * Pipeline order matters:
 *   1. contrastStretch  — fixes the luminance range first (other ops work better after)
 *   2. saturate         — boost colour distinctiveness
 *   3. lightenBackground — push near-white BG to white (before sharpen to avoid halos)
 *   4. unsharpMask      — sharpen edges last (after colour changes are stable)
 *   [5. AI step]        — future: semantic BG removal, subject enhancement
 *
 * FAILURE CONTRACT:
 * - If any step throws, the pipeline catches and continues with the previous result
 * - If the entire pipeline fails, the caller receives a result with success: false
 *   and the original dataUrl so the user can continue with the untouched photo
 *
 * FUTURE AI INTEGRATION POINT:
 * Add an async AI step between step 4 and the return:
 *
 *   if (options.useAI) {
 *     try {
 *       const aiResult = await callRemBgApi(currentDataUrl)
 *       currentData    = aiResult
 *       appliedSteps.push('ai-background-removal')
 *     } catch {
 *       // fall through — AI is optional
 *     }
 *   }
 */

import {
  contrastStretch,
  saturate,
  unsharpMask,
  lightenBackground,
} from './enhance'

// ─── Types ────────────────────────────────────────────────────────────────────

export interface PipelineOptions {
  contrast?:   boolean   // default true
  saturation?: boolean   // default true
  background?: boolean   // default true
  sharpen?:    boolean   // default true
}

export interface PipelineResult {
  success:       boolean
  dataUrl:       string           // enhanced image (or original if failed)
  appliedSteps:  string[]         // which operations actually changed pixels
  skippedSteps:  string[]         // which were skipped (with reasons)
  error?:        string           // set if pipeline threw entirely
}

const DEFAULT_OPTIONS: Required<PipelineOptions> = {
  contrast:   true,
  saturation: true,
  background: true,
  sharpen:    true,
}

// ─── Canvas helpers ───────────────────────────────────────────────────────────

function dataUrlToImageData(dataUrl: string): Promise<ImageData> {
  return new Promise((resolve, reject) => {
    const img    = new Image()
    img.onload   = () => {
      const canvas = document.createElement('canvas')
      canvas.width  = img.naturalWidth
      canvas.height = img.naturalHeight
      const ctx  = canvas.getContext('2d')
      if (!ctx) return reject(new Error('Cannot get 2D context'))
      ctx.drawImage(img, 0, 0)
      resolve(ctx.getImageData(0, 0, canvas.width, canvas.height))
    }
    img.onerror  = () => reject(new Error('Failed to load image'))
    img.src      = dataUrl
  })
}

function imageDataToDataUrl(data: ImageData): string {
  const canvas  = document.createElement('canvas')
  canvas.width  = data.width
  canvas.height = data.height
  const ctx     = canvas.getContext('2d')
  if (!ctx) throw new Error('Cannot get 2D context')
  ctx.putImageData(data, 0, 0)
  return canvas.toDataURL('image/jpeg', 0.92)
}

// ─── Pipeline ─────────────────────────────────────────────────────────────────

/**
 * Run the full enhancement pipeline on a base64 dataUrl.
 * Always resolves — never rejects. On failure, returns original dataUrl.
 *
 * Must be called in a browser context (uses canvas API).
 */
export async function runEnhancePipeline(
  dataUrl:  string,
  options:  PipelineOptions = {}
): Promise<PipelineResult> {
  const opts = { ...DEFAULT_OPTIONS, ...options }
  const appliedSteps: string[] = []
  const skippedSteps: string[] = []

  let currentData: ImageData

  try {
    currentData = await dataUrlToImageData(dataUrl)
  } catch (err) {
    return {
      success:      false,
      dataUrl,
      appliedSteps: [],
      skippedSteps: [],
      error:        err instanceof Error ? err.message : 'Failed to decode image',
    }
  }

  // Helper to safely run one step
  function runStep(
    name:    string,
    enabled: boolean,
    fn:      (d: ImageData) => { data: ImageData; applied: boolean; reason?: string }
  ) {
    if (!enabled) { skippedSteps.push(`${name} (disabled)`); return }
    try {
      const result = fn(currentData)
      if (result.applied) {
        currentData = result.data
        appliedSteps.push(name)
      } else {
        skippedSteps.push(`${name} (${result.reason ?? 'skipped'})`)
      }
    } catch (err) {
      // Silently skip failing steps — pipeline is fault-tolerant
      skippedSteps.push(`${name} (error: ${err instanceof Error ? err.message : 'unknown'})`)
    }
  }

  // ── Steps in order ────────────────────────────────────────────────────────
  runStep('contrast',    opts.contrast,   contrastStretch)
  runStep('saturation',  opts.saturation, saturate)
  runStep('background',  opts.background, lightenBackground)
  runStep('sharpen',     opts.sharpen,    unsharpMask)

  // ── FUTURE AI STEP GOES HERE ─────────────────────────────────────────────
  // if (opts.useAI) {
  //   try {
  //     const result = await callAIEnhanceService(imageDataToDataUrl(currentData))
  //     currentData  = await dataUrlToImageData(result.dataUrl)
  //     appliedSteps.push('ai-background-removal')
  //   } catch { skippedSteps.push('ai-background-removal (service unavailable)') }
  // }

  try {
    const enhancedDataUrl = imageDataToDataUrl(currentData)
    return { success: true, dataUrl: enhancedDataUrl, appliedSteps, skippedSteps }
  } catch (err) {
    return {
      success:      false,
      dataUrl,
      appliedSteps: [],
      skippedSteps,
      error:        err instanceof Error ? err.message : 'Failed to encode result',
    }
  }
}
