/**
 * image-processing/enhance.ts
 *
 * Canvas-based image preprocessing operations.
 * Every function is a pure pixel transformation: takes ImageData, returns
 * a new ImageData. No side effects, no DOM mutations beyond what's passed in.
 *
 * WHY LOCAL vs AI SERVICE:
 * These operations run in <10ms even on large images, work offline, and are
 * completely private (pixels never leave the device). They solve the 80% case:
 * - Low contrast → contrastStretch
 * - Washed-out colours → saturate
 * - Soft edges → unsharpMask
 * - Distracting light backgrounds → lightenBackground
 *
 * The remaining 20% (semantic background removal, subject-awareness) requires
 * a model. The enhancePipeline.ts orchestrator accepts an optional AI step
 * so a rembg/SAM API call can slot in without touching this file.
 *
 * KNOWN FAILURE CASES:
 * - Dark subject on dark background: contrast stretch helps but may not
 *   separate subject from BG — user should be warned.
 * - Blonde/light-skin portraits: saturation boost can over-pink skin.
 *   Capped at 1.3× to mitigate.
 * - Very dark photos: unsharp mask amplifies shadow noise.
 *   Only applied when mean luminance > 30/255.
 * - Transparent PNGs: all operations skip alpha < 128 pixels.
 */

// ─── Types ────────────────────────────────────────────────────────────────────

/** Result of a single enhance operation */
export interface EnhanceResult {
  data:    ImageData
  applied: boolean    // false if operation was skipped (e.g. already high contrast)
  reason?: string     // why skipped, for debug/logging
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

/** Clamp a value to [0, 255] */
function clamp(v: number): number {
  return Math.max(0, Math.min(255, Math.round(v)))
}

/** RGB → HSL (all values 0–1) */
function rgbToHsl(r: number, g: number, b: number): [number, number, number] {
  r /= 255; g /= 255; b /= 255
  const max = Math.max(r, g, b), min = Math.min(r, g, b)
  const l   = (max + min) / 2
  if (max === min) return [0, 0, l]
  const d = max - min
  const s = l > 0.5 ? d / (2 - max - min) : d / (max + min)
  let h: number
  switch (max) {
    case r: h = ((g - b) / d + (g < b ? 6 : 0)) / 6; break
    case g: h = ((b - r) / d + 2) / 6; break
    default: h = ((r - g) / d + 4) / 6
  }
  return [h, s, l]
}

/** HSL → RGB (H,S,L all 0–1), returns 0–255 */
function hslToRgb(h: number, s: number, l: number): [number, number, number] {
  if (s === 0) {
    const v = Math.round(l * 255)
    return [v, v, v]
  }
  const hue2rgb = (p: number, q: number, t: number) => {
    if (t < 0) t += 1
    if (t > 1) t -= 1
    if (t < 1 / 6) return p + (q - p) * 6 * t
    if (t < 1 / 2) return q
    if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6
    return p
  }
  const q = l < 0.5 ? l * (1 + s) : l + s - l * s
  const p = 2 * l - q
  return [
    Math.round(hue2rgb(p, q, h + 1 / 3) * 255),
    Math.round(hue2rgb(p, q, h) * 255),
    Math.round(hue2rgb(p, q, h - 1 / 3) * 255),
  ]
}

// ─── Operations ───────────────────────────────────────────────────────────────

/**
 * Stretch the luminance histogram so the darkest opaque pixel → 0
 * and the brightest → 255. Dramatically improves patterns from low-contrast
 * phone photos taken in dim light.
 *
 * Skipped if contrast is already ≥80% of full range (avoids over-processing).
 * Uses 2nd/98th percentile instead of min/max to avoid outlier blown highlights.
 */
export function contrastStretch(src: ImageData): EnhanceResult {
  const d  = src.data
  const lumas: number[] = []

  for (let i = 0; i < d.length; i += 4) {
    if (d[i + 3] < 128) continue
    lumas.push(0.299 * d[i] + 0.587 * d[i + 1] + 0.114 * d[i + 2])
  }

  if (lumas.length === 0) return { data: src, applied: false, reason: 'no opaque pixels' }

  lumas.sort((a, b) => a - b)
  const lo  = lumas[Math.floor(lumas.length * 0.02)]
  const hi  = lumas[Math.floor(lumas.length * 0.98)]
  const rng = hi - lo

  if (rng >= 0.8 * 255) {
    return { data: src, applied: false, reason: 'contrast already sufficient' }
  }

  const out = new ImageData(new Uint8ClampedArray(d), src.width, src.height)

  for (let i = 0; i < out.data.length; i += 4) {
    if (out.data[i + 3] < 128) continue
    for (let c = 0; c < 3; c++) {
      out.data[i + c] = clamp(((d[i + c] - lo) / rng) * 255)
    }
  }

  return { data: out, applied: true }
}

/**
 * Boost colour saturation to push muted tones toward distinct colour zones.
 * This directly improves palette reduction quality by making colours more
 * separable in LAB space.
 *
 * Operates in HSL space. Capped at 1.3× to avoid skin-tone distortion.
 * Skipped if image is already highly saturated (mean S > 0.5).
 */
export function saturate(src: ImageData, factor = 1.25): EnhanceResult {
  const d = src.data
  // Cap factor to avoid portrait distortion
  const safeFactor = Math.min(1.3, factor)

  // Measure mean saturation — skip if already vivid
  let totalS = 0, count = 0
  for (let i = 0; i < d.length; i += 4) {
    if (d[i + 3] < 128) continue
    const [, s] = rgbToHsl(d[i], d[i + 1], d[i + 2])
    totalS += s; count++
  }
  if (count === 0) return { data: src, applied: false, reason: 'no opaque pixels' }
  if (totalS / count > 0.5) {
    return { data: src, applied: false, reason: 'already well saturated' }
  }

  const out = new ImageData(new Uint8ClampedArray(d), src.width, src.height)

  for (let i = 0; i < out.data.length; i += 4) {
    if (out.data[i + 3] < 128) continue
    const [h, s, l] = rgbToHsl(d[i], d[i + 1], d[i + 2])
    const [r, g, b] = hslToRgb(h, Math.min(1, s * safeFactor), l)
    out.data[i]     = r
    out.data[i + 1] = g
    out.data[i + 2] = b
  }

  return { data: out, applied: true }
}

/**
 * Unsharp mask — sharpens edges by subtracting a blurred version.
 * Helps grid cells at colour boundaries get assigned the right colour
 * rather than a blended midpoint.
 *
 * Uses a simple 3×3 box blur as the base (fast, good enough for sharpening).
 * Strength capped at 0.4 to avoid haloing on phone photos.
 *
 * Skipped if mean luminance < 30 (very dark photo — noise amplification risk).
 */
export function unsharpMask(src: ImageData, strength = 0.35): EnhanceResult {
  const d = src.data
  const w = src.width, h = src.height

  // Check mean luminance
  let totalL = 0, count = 0
  for (let i = 0; i < d.length; i += 4) {
    if (d[i + 3] < 128) continue
    totalL += 0.299 * d[i] + 0.587 * d[i + 1] + 0.114 * d[i + 2]
    count++
  }
  if (count === 0) return { data: src, applied: false, reason: 'no opaque pixels' }
  if (totalL / count < 30) {
    return { data: src, applied: false, reason: 'image too dark — skipping sharpen to avoid noise' }
  }

  const safeStrength = Math.min(0.4, strength)

  // 3×3 box blur
  const blurred = new Uint8ClampedArray(d.length)
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      let rS = 0, gS = 0, bS = 0, n = 0
      for (let dy = -1; dy <= 1; dy++) {
        for (let dx = -1; dx <= 1; dx++) {
          const nx = x + dx, ny = y + dy
          if (nx < 0 || nx >= w || ny < 0 || ny >= h) continue
          const j = (ny * w + nx) * 4
          rS += d[j]; gS += d[j + 1]; bS += d[j + 2]; n++
        }
      }
      const i = (y * w + x) * 4
      blurred[i]     = rS / n
      blurred[i + 1] = gS / n
      blurred[i + 2] = bS / n
      blurred[i + 3] = d[i + 3]
    }
  }

  // Subtract blur from original
  const out = new ImageData(new Uint8ClampedArray(d), w, h)
  for (let i = 0; i < out.data.length; i += 4) {
    if (out.data[i + 3] < 128) continue
    for (let c = 0; c < 3; c++) {
      out.data[i + c] = clamp(d[i + c] + safeStrength * (d[i + c] - blurred[i + c]))
    }
  }

  return { data: out, applied: true }
}

/**
 * Lighten near-white background pixels to pure white.
 * Reduces the palette slots stolen by background noise in outdoor shots.
 *
 * A pixel is "background-like" if it is light (L > 0.82) AND low saturation (S < 0.15).
 * Pushes those pixels toward #ffffff.
 *
 * Skipped if fewer than 10% of pixels qualify as background-like
 * (avoids accidentally whitening a subject that IS light-coloured).
 *
 * KNOWN FAILURE: white dogs, white cats, blonde hair — may partially erase subject.
 * TODO (AI step): replace with semantic segmentation for these cases.
 */
export function lightenBackground(src: ImageData): EnhanceResult {
  const d = src.data
  let bgCount = 0, total = 0

  for (let i = 0; i < d.length; i += 4) {
    if (d[i + 3] < 128) continue
    total++
    const [, s, l] = rgbToHsl(d[i], d[i + 1], d[i + 2])
    if (l > 0.82 && s < 0.15) bgCount++
  }

  if (total === 0) return { data: src, applied: false, reason: 'no opaque pixels' }
  if (bgCount / total < 0.10) {
    return { data: src, applied: false, reason: 'insufficient background-like area' }
  }

  const out = new ImageData(new Uint8ClampedArray(d), src.width, src.height)
  for (let i = 0; i < out.data.length; i += 4) {
    if (out.data[i + 3] < 128) continue
    const [, s, l] = rgbToHsl(d[i], d[i + 1], d[i + 2])
    if (l > 0.82 && s < 0.15) {
      // Blend toward white proportional to how "background-like" the pixel is
      const t = Math.min(1, (l - 0.82) / 0.18 + (0.15 - s) / 0.15) * 0.7
      out.data[i]     = clamp(d[i]     + t * (255 - d[i]))
      out.data[i + 1] = clamp(d[i + 1] + t * (255 - d[i + 1]))
      out.data[i + 2] = clamp(d[i + 2] + t * (255 - d[i + 2]))
    }
  }

  return { data: out, applied: true }
}
