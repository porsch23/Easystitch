import Link from 'next/link'

export default function LandingPage() {
  return (
    <main className="min-h-screen bg-cream-50 flex flex-col">

      {/* Hero */}
      <section className="flex-1 flex flex-col items-center justify-center px-6 pt-16 pb-8 text-center">

        {/* Badge */}
        <div className="inline-flex items-center gap-2 bg-rose-DEFAULT/10 text-rose-deep rounded-full px-4 py-1.5 text-xs font-body font-medium mb-6">
          🧶 Free pattern maker for beginners
        </div>

        {/* Headline */}
        <h1 className="font-display text-4xl text-ink leading-tight mb-4">
          Turn any photo into<br />
          <span className="text-rose-DEFAULT">a crochet pattern</span>
        </h1>

        <p className="font-body text-ink/60 text-base max-w-xs leading-relaxed mb-10">
          Upload a photo and EasyStitch builds a stitch-by-stitch graph pattern — ready to crochet or download.
        </p>

        {/* Sample pattern preview card */}
        <div className="w-full max-w-xs bg-white rounded-3xl shadow-float p-4 mb-10">
          <div className="rounded-2xl overflow-hidden mb-3 bg-cream-100 aspect-square flex items-center justify-center">
            {/* Placeholder grid preview */}
            <SamplePatternGrid />
          </div>
          <div className="flex items-center justify-between px-1">
            <div className="flex gap-1.5">
              {['#e8786e','#89a882','#c9a96e','#faf3e7','#5c7a55','#2a2118'].map(hex => (
                <div
                  key={hex}
                  className="w-4 h-4 rounded-full border border-white shadow-sm"
                  style={{ backgroundColor: hex }}
                />
              ))}
            </div>
            <span className="text-xs font-body text-ink/40">20×20 grid</span>
          </div>
        </div>

        {/* Steps preview */}
        <div className="flex items-center gap-3 text-xs font-body text-ink/40 mb-12">
          {['Upload', 'Customize', 'Download'].map((step, i) => (
            <div key={step} className="flex items-center gap-3">
              <span>{step}</span>
              {i < 2 && <span>→</span>}
            </div>
          ))}
        </div>
      </section>

      {/* Sticky CTA */}
      <div className="sticky bottom-0 bg-cream-50/95 backdrop-blur-sm border-t border-cream-200 px-6 pt-4 pb-safe">
        <Link
          href="/upload"
          className="block w-full bg-rose-DEFAULT text-white text-center font-body font-semibold text-base py-4 rounded-2xl shadow-soft active:scale-[0.98] transition-transform"
        >
          Make My Pattern →
        </Link>
        <p className="text-center text-xs font-body text-ink/30 mt-3 pb-2">
          No account needed · Free to download
        </p>
      </div>

    </main>
  )
}

// Mini sample grid rendered purely from divs
function SamplePatternGrid() {
  const palette = ['#e8786e','#89a882','#c9a96e','#faf3e7','#5c7a55','#2a2118']
  const size = 12

  return (
    <div
      className="grid gap-px p-2"
      style={{ gridTemplateColumns: `repeat(${size}, 1fr)`, width: '100%' }}
    >
      {Array.from({ length: size * size }).map((_, i) => {
        const row = Math.floor(i / size)
        const col = i % size
        const colorIndex = (row + col * 2) % palette.length
        return (
          <div
            key={i}
            className="aspect-square rounded-sm"
            style={{ backgroundColor: palette[colorIndex] }}
          />
        )
      })}
    </div>
  )
}
