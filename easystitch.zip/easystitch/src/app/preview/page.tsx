'use client'

/**
 * app/preview/page.tsx
 *
 * Step 4: Pattern preview.
 *
 * FIX #9: Removed step/onBack props from <Header> — Header derives navigation
 * from pathname automatically, those props were silently ignored.
 * FIX #12: ZoomControls removed — PatternCanvas owns its own CSS-transform
 * zoom via pinch gesture. cellSize is fixed at a comfortable preview default.
 */

import { useRouter } from 'next/navigation'
import Header             from '@/components/layout/Header'
import StepIndicator      from '@/components/ui/StepIndicator'
import LoadingSpinner     from '@/components/ui/LoadingSpinner'
import PatternCanvas      from '@/components/preview/PatternCanvas'
import ColorLegend        from '@/components/preview/ColorLegend'
import PatternMetadata    from '@/components/preview/PatternMetadata'
import OriginalImageThumb from '@/components/preview/OriginalImageThumb'
import { usePattern }     from '@/context/PatternContext'

export default function PreviewPage() {
  const router            = useRouter()
  const { state }         = usePattern()
  const { patternData, rawImage, enhancedImage, isGenerating } = state

  // Show spinner while generation runs (triggered from settings page)
  if (isGenerating) {
    return (
      <main style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column', background: '#FAF6EF' }}>
        <Header />
        <StepIndicator />
        <LoadingSpinner message="Counting your stitches…" />
      </main>
    )
  }

  if (!patternData) {
    return (
      <main style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column', background: '#FAF6EF' }}>
        <Header />
        <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 32 }}>
          <div style={{ textAlign: 'center' }}>
            <p style={{ fontSize: 14, color: '#6B5744', marginBottom: 16, fontFamily: "'DM Sans', sans-serif" }}>
              No pattern yet. Choose your settings to generate one.
            </p>
            <button
              onClick={() => router.push('/settings')}
              style={{
                background: '#C4614A', color: 'white', border: 'none',
                borderRadius: 12, padding: '12px 24px',
                fontFamily: "'DM Sans', sans-serif", fontSize: 14, cursor: 'pointer',
              }}
            >
              Back to Settings
            </button>
          </div>
        </div>
      </main>
    )
  }

  const imageToShow = enhancedImage ?? rawImage

  return (
    <main style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column', background: '#FAF6EF' }}>
      <Header />
      <StepIndicator />

      <section style={{
        flex: 1,
        display: 'flex', flexDirection: 'column',
        gap: 16,
        padding: '8px 20px 220px',
        overflowY: 'auto',
      }}>

        <div>
          <h1 style={{
            fontFamily: "'Playfair Display', serif",
            fontSize: 26, fontWeight: 700,
            color: '#2C2218', lineHeight: 1.25, marginBottom: 4,
          }}>
            Your pattern is ready!
          </h1>
          <p style={{ fontSize: 13, color: '#6B5744', fontFamily: "'DM Sans', sans-serif" }}>
            {patternData.meta.width}×{patternData.meta.height} · {patternData.palette.length} colours
            · Pinch to zoom · Double-tap to reset
          </p>
        </div>

        <OriginalImageThumb originalSrc={imageToShow} pattern={patternData} />

        {/* Pattern canvas — self-contained zoom/pan */}
        <div>
          <p style={{
            fontSize: 11, fontWeight: 500,
            textTransform: 'uppercase', letterSpacing: '0.08em',
            color: '#6B5744', fontFamily: "'DM Sans', sans-serif",
            marginBottom: 10,
          }}>
            Pattern Grid
          </p>
          <PatternCanvas pattern={patternData} cellSize={14} />
        </div>

        <ColorLegend
          palette={patternData.palette}
          totalStitches={patternData.meta.totalStitches}
        />

        <PatternMetadata meta={patternData.meta} />

        <div style={{
          background: 'rgba(122,158,126,0.1)',
          borderRadius: 16, padding: '14px 16px',
          display: 'flex', gap: 12, alignItems: 'flex-start',
        }}>
          <span style={{ fontSize: 20, flexShrink: 0 }}>💡</span>
          <p style={{ fontSize: 13, color: '#6B5744', lineHeight: 1.65, fontFamily: "'DM Sans', sans-serif" }}>
            Work from the <strong>bottom-left corner</strong>, one row at a time.
            Each symbol = one stitch in that colour.
          </p>
        </div>

      </section>

      {/* Fixed bottom bar */}
      <div style={{
        position: 'fixed', bottom: 0, left: '50%',
        transform: 'translateX(-50%)',
        width: '100%', maxWidth: 430,
        padding: '16px 20px max(20px, env(safe-area-inset-bottom))',
        background: 'linear-gradient(to top, #FAF6EF 80%, transparent)',
        zIndex: 50, display: 'flex', flexDirection: 'column', gap: 8,
      }}>
        <button
          onClick={() => router.push('/export')}
          style={{
            width: '100%', padding: '17px 24px',
            background: '#C4614A', color: 'white',
            border: 'none', borderRadius: 16,
            fontFamily: "'DM Sans', sans-serif",
            fontSize: 16, fontWeight: 500, cursor: 'pointer',
            boxShadow: '0 4px 20px rgba(196,97,74,0.28)',
          }}
        >
          Export PDF →
        </button>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          <button
            onClick={() => router.push('/settings')}
            style={{
              width: '100%', padding: '13px 16px', background: 'white', color: '#6B5744',
              border: '1.5px solid #E4D9C8', borderRadius: 14,
              fontFamily: "'DM Sans', sans-serif", fontSize: 14, cursor: 'pointer',
            }}
          >
            ✏️ Edit settings
          </button>
        </div>
      </div>
    </main>
  )
}
